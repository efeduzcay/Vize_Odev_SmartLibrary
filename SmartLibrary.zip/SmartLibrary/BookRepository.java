import java.sql.*;
import java.util.ArrayList;

public class BookRepository {
    public void add(Book book) {
        String sql = "INSERT INTO books(title, author, year) VALUES(?,?,?)";
        try (Connection conn = Database.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setInt(3, book.getYear());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public ArrayList<Book> getAll() {
        ArrayList<Book> list = new ArrayList<>();
        try (Connection conn = Database.connect(); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT * FROM books");
            while (rs.next()) {
                list.add(new Book(rs.getInt("id"), rs.getString("title"), rs.getString("author"), rs.getInt("year")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
