import java.sql.*;
import java.util.ArrayList;

public class StudentRepository {
    public void add(Student s) {
        String sql = "INSERT INTO students(name, department) VALUES(?,?)";
        try (Connection conn = Database.connect(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDepartment());
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public ArrayList<Student> getAll() {
        ArrayList<Student> list = new ArrayList<>();
        try (Connection conn = Database.connect(); Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery("SELECT * FROM students");
            while (rs.next()) {
                list.add(new Student(rs.getInt("id"), rs.getString("name"), rs.getString("department")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
