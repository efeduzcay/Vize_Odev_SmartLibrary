import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // SQLite driver’ı zorla yükle
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return; // Eğer driver yoksa programı durdur
        }

        Database.init();
        BookRepository bookRepo = new BookRepository();
        StudentRepository studentRepo = new StudentRepository();
        LoanRepository loanRepo = new LoanRepository();

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- SmartLibrary Menü ---");
            System.out.println("1- Kitap Ekle");
            System.out.println("2- Kitapları Listele");
            System.out.println("3- Öğrenci Ekle");
            System.out.println("4- Öğrencileri Listele");
            System.out.println("5- Kitap Ödünç Ver");
            System.out.println("6- Ödünç Kayıtlarını Listele");
            System.out.println("7- Kitap Teslim Al");
            System.out.println("0- Çıkış");
            System.out.print("Seçiminiz: ");

            int sec = -1;
            try {
                sec = sc.nextInt();
            } catch (Exception e) {
                System.out.println("Lütfen geçerli bir sayı girin!");
                sc.nextLine(); // hatalı girişi temizle
                continue;
            }
            sc.nextLine(); // buffer temizle

            if (sec == 1) {
                System.out.print("Kitap başlığı: "); String t = sc.nextLine();
                System.out.print("Yazar: "); String a = sc.nextLine();
                System.out.print("Yıl: "); int y = sc.nextInt(); sc.nextLine();
                bookRepo.add(new Book(t,a,y));
                System.out.println("Kitap eklendi.");
            }
            else if (sec == 2) {
                System.out.println("\n--- Kitap Listesi ---");
                for (Book b : bookRepo.getAll()) {
                    System.out.println(b.getId() + " - " + b.getTitle() + " | " + b.getAuthor() + " | " + b.getYear());
                }
            }
            else if (sec == 3) {
                System.out.print("Öğrenci adı: "); String n = sc.nextLine();
                System.out.print("Bölüm: "); String d = sc.nextLine();
                studentRepo.add(new Student(n,d));
                System.out.println("Öğrenci eklendi.");
            }
            else if (sec == 4) {
                System.out.println("\n--- Öğrenci Listesi ---");
                for (Student s : studentRepo.getAll()) {
                    System.out.println(s.getId() + " - " + s.getName() + " | " + s.getDepartment());
                }
            }
            else if (sec == 0) {
                System.out.println("Programdan çıkılıyor...");
                break;
            }
            else {
                System.out.println("Geçersiz seçim!");
            }
        }

        sc.close();
    }
}
