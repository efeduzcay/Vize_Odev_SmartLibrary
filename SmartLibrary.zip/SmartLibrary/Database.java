import java.sql.*;

public class Database {
    private static final String URL = "jdbc:sqlite:smartlibrary.db";

    public static Connection connect() {
        try {
            return DriverManager.getConnection(URL);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void init() {
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS books(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, author TEXT, year INTEGER)");
            stmt.execute("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, department TEXT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY AUTOINCREMENT, bookId INTEGER, studentId INTEGER, dateBorrowed TEXT, dateReturned TEXT)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
